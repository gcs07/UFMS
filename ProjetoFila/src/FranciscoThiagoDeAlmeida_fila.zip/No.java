
public class No{

	int chave;
	No proximo;
	
	//construtor
	No(int ch){
		chave = ch;
		proximo = null;
	}
}